export default {
    primary: "rgb(0, 74, 173)",
    primaryLight: "#1e5ab0",
    white: "rgb(255, 255, 255)",
    black: "rgb(17, 10, 1)",
    grey: "grey",
    mediumGrey: "rgb(190, 190, 190)",
    lightGrey: "rgb(250, 250, 250)",
    red: "#dd3e3e"
}